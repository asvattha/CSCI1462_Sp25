OK_FORMAT = True

test = {   'name': 'q2(a)',
    'points': None,
    'suites': [{'cases': [{'code': '>>> your_ans.item() == 53181784\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
