OK_FORMAT = True

test = {   'name': 'q2(f)',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(your_ans) == 19\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.sort(your_ans)[0].item() == 261.08\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
