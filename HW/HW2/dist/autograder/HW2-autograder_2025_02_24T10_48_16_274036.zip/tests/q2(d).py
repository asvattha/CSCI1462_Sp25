OK_FORMAT = True

test = {   'name': 'q2(d)',
    'points': None,
    'suites': [{'cases': [{'code': '>>> your_ans.item() == 116999.92\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
