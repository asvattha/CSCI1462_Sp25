OK_FORMAT = True

test = {   'name': 'q2(e)',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> your_ans.shape[0] == 19\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> ('CompSci' not in your_ans) == True\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
