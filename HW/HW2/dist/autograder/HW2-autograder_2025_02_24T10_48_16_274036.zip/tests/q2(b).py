OK_FORMAT = True

test = {'name': 'q2(b)', 'points': None, 'suites': [{'cases': [{'code': ">>> your_ans == 'Sienna'\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
