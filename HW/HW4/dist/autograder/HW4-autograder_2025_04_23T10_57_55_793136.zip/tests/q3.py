OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [{'cases': [{'code': '>>> (0 < your_choice < 4) == True\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
