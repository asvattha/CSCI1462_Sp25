OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> pop_dist.shape == (2,)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> (0 < pop_dist[1] < 1 and 0 < pop_dist[0] < 1).item() == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
