OK_FORMAT = True

test = {   'name': 'q6',
    'points': None,
    'suites': [{'cases': [{'code': '>>> (0 < one_simulation() < 1).item() == True\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
