OK_FORMAT = True

test = {   'name': 'q4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> calculate_statistic(np.array([0.5, 0.5]), np.array([0.4, 0.1])).item() == 0.25\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> calculate_statistic(np.array([0.4, 0.1]), np.array([0.4, 0.1])).item() == 0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
