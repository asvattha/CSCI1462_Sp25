OK_FORMAT = True

test = {   'name': 'q8',
    'points': None,
    'suites': [{'cases': [{'code': '>>> (p_value > 0.05).item() == True\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
