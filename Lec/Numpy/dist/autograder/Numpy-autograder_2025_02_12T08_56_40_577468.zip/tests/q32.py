OK_FORMAT = True

test = {   'name': 'q32',
    'points': None,
    'suites': [{'cases': [{'code': '>>> np.isclose(3.14, np.round(pi, 2)).item()\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
