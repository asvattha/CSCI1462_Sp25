OK_FORMAT = True

test = {'name': 'q28', 'points': None, 'suites': [{'cases': [{'code': '>>> your_ans.item() == 2\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
