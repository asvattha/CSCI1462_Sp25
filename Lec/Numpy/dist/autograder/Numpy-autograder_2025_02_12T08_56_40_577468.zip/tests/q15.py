OK_FORMAT = True

test = {   'name': 'q15',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> C.shape == (3, 2)\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> C[-1, -1].item() == 23\nnp.True_', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
