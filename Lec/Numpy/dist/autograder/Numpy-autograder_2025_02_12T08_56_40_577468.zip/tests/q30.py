OK_FORMAT = True

test = {   'name': 'q30',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> A.shape == (2, 4)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> A[0, 2].item() == 0 and A[0, 1].item() == 0 and (A[1, 2].item() == 0)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
