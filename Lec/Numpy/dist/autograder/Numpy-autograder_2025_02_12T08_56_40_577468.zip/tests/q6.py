OK_FORMAT = True

test = {   'name': 'q6',
    'points': None,
    'suites': [{'cases': [{'code': '>>> arr3d.shape == (3, 3, 3)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
