OK_FORMAT = True

test = {   'name': 'q33b',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(nvidia_diff) == 11\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(nvidia_diff[-1], 2.75).item()\nnp.True_', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
