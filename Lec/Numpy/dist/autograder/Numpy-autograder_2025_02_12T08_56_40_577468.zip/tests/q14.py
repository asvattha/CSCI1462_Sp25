OK_FORMAT = True

test = {   'name': 'q14',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> temps_in_fahr[-1] == 77\nnp.True_', 'hidden': False, 'locked': False}, {'code': '>>> len(temps_in_fahr) == 4\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
