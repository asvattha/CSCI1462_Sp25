OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> isinstance(my_fruits, np.ndarray)\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> len(my_fruits) == 3\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
