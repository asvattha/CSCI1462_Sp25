OK_FORMAT = True

test = {   'name': 'q22',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> your_ans.shape == (5, 2)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> your_ans[-1, -1].item() == -4\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
