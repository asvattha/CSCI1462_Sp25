OK_FORMAT = True

test = {   'name': 'q33c',
    'points': None,
    'suites': [{'cases': [{'code': '>>> your_ans.item() == True\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
