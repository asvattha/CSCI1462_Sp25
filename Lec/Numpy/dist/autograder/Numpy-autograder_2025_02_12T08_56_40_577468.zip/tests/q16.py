OK_FORMAT = True

test = {   'name': 'q16',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> your_ans.shape == (4,)\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> your_ans[-1].item() == 400\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
