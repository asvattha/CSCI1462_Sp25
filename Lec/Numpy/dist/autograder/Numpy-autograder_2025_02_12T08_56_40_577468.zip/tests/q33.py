OK_FORMAT = True

test = {   'name': 'q33',
    'points': None,
    'suites': [{'cases': [{'code': '>>> np.isclose(40.77, your_ans).item()\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
