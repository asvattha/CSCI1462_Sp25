OK_FORMAT = True

test = {'name': 'q33e', 'points': None, 'suites': [{'cases': [{'code': '>>> your_ans == 3\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
