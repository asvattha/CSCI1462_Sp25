OK_FORMAT = True

test = {'name': 'q27', 'points': None, 'suites': [{'cases': [{'code': '>>> your_ans.item() == 9\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
